// src/components/EditEmployeeDetails.js
import React, { useEffect, useState } from 'react';
import { Formik, Form, Field, FieldArray, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  contact: Yup.string().required('Contact is required'),
  aadharNumber: Yup.string().required('Aadhar Number is required'),
  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      sscPassingYear: Yup.number().required('SSC Passing Year is required'),
      sscPercentage: Yup.number().required('SSC Percentage is required'),
      // Add similar validations for other education fields
    })
  ),
  employmentHistory: Yup.array().of(
    Yup.object().shape({
      companyName: Yup.string().required('Company Name is required'),
      location: Yup.string().required('Location is required'),
      fromDate: Yup.date().required('From Date is required'),
      toDate: Yup.date().required('To Date is required'),
      designation: Yup.string().required('Designation is required'),
      // Add similar validations for other employment history fields
    })
  ),
});



const EditEmployeeDetails = ({ employeeId, onSave }) => {
  const [initialValues, setinitialValues] =useState ([
    {
      firstName: '',
      lastName: '',
      email: '',
      contact: '',
      aadharNumber: '',
      education: [
        {
          sscSchool: '',
          sscUniversity: '',
          sscPassingYear: '',
          sscPercentage: '',
          hscDiplomaCollege: '',
          hscDiplomaUniversity: '',
          hscDiplomaPassingYear: '',
          hscDiplomaPercentage: '',
          graduationCollege: '',
          graduationUniversity: '',
          graduationPassingYear: '',
          graduationPercentage: '',
        },
      ],
      employmentHistory: [
        {
          companyName: '',
          location: '',
          fromDate: '',
          toDate: '',
          designation: '',
        },
      ],
    }
  ])

  useEffect(() => {
    // Fetch the employee data by ID and set it as the initial values
    axios.get(`http://localhost:3000/employees/${employeeId}`)
      .then((response) => {
        const employeeData = response.data;
        // Set the fetched data as initial values for the form
        // This assumes that the fetched data structure matches your form structure
        // For example: { firstName, lastName, email, contact, aadharNumber, education, employmentHistory }
        // You may need to adapt this code according to your data structure
        setinitialValues(employeeData);
      })
      .catch((error) => {
        console.error('Error fetching employee data:', error);
      });
  }, [employeeId]);

  const handleSubmit = async (values) => {
    try {
      // Send the edited data to your JSON server
      await axios.put(`http://localhost:3000/employees/${employeeId}`, values);
      alert('Employee details updated successfully!');
      // onEdit(); // Trigger a callback to notify the parent component of the update
    } catch (error) {
      console.error('Error updating employee details:', error);
    }
  };


  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSave}
    >  {({ handleSubmit, handleChange, handleBlur, values, errors }) => (
      <Form>
        <>
        <h2>Edit Employee Details</h2>

        {/* Personal Details */}
        <h3>Personal Details</h3>
        <div className="form-group">
          <label htmlFor="firstName">First Name:</label>
          <Field type="text" id="firstName" name="firstName" className="form-control" />
          <ErrorMessage name="firstName" component="div" className="text-danger" />
        </div>
        {/* Add fields for lastName, email, contact, aadharNumber, etc. */}
        {/* ...

        {/* Education Details */}
        <h3>Education Details</h3>
        <FieldArray name="education">
          {({ push, remove }) => (
            <>
              {values.education.map((edu, index) => (
                <div key={index}>
                  <h4>Education Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`education[${index}].sscSchool`}>SSC School:</label>
                    <Field type="text" id={`education[${index}].sscSchool`} name={`education[${index}].sscSchool`} className="form-control" />
                    <ErrorMessage name={`education[${index}].sscSchool`} component="div" className="text-danger" />
                  </div>
                  {/* Add fields for other education details */}

                  <button type="button" onClick={() => remove(index)}>
                    Remove Education Entry
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => {
                  push({
                    sscSchool: '',
                    sscUniversity: '',
                    sscPassingYear: '',
                    sscPercentage: '',
                  });
                }}
              >
                Add Education Entry
              </button>
            </>
          )}
        </FieldArray>

        {/* Employment History */}
        <h3>Employment History</h3>
        <FieldArray name="employmentHistory">
          {({ push, remove }) => (
            <>
              {values.employmentHistory.map((emp, index) => (
                <div key={index}>
                  <h4>Employment History Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].companyName`}>Company Name:</label>
                    <Field type="text" id={`employmentHistory[${index}].companyName`} name={`employmentHistory[${index}].companyName`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].companyName`} component="div" className="text-danger" />
                  </div>
                  {/* Add fields for other employment history details */}
                  <button type="button" onClick={() => remove(index)}>
                    Remove Employment History Entry
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => {
                  push({
                    companyName: '',
                    location: '',
                    fromDate: '',
                    toDate: '',
                    designation: '',
                  });
                }}
              >
                Add Employment History Entry
              </button>
            </>
          )}
        </FieldArray>

        <button type="submit" className="btn btn-primary">Save Changes</button>
        </>
        
      </Form>)}
    </Formik>
  );
};

export default EditEmployeeDetails;
