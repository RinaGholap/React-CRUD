// src/components/EditEmployeeDetails.js
import React from 'react';
import { Formik, Form, Field, FieldArray, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  // Validation schema for personal details
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  contact: Yup.string().required('Contact is required'),
  aadharNumber: Yup.string().required('Aadhar Number is required'),

  // Validation schema for education details
  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      sscPassingYear: Yup.number().required('SSC Passing Year is required'),
      sscPercentage: Yup.number().required('SSC Percentage is required'),

      // Similar validations for other education fields
    })
  ),

  // Validation schema for employment history details
  employmentHistory: Yup.array().of(
    Yup.object().shape({
      companyName: Yup.string().required('Company Name is required'),
      location: Yup.string().required('Location is required'),
      fromDate: Yup.date().required('From Date is required'),
      toDate: Yup.date().required('To Date is required'),
      designation: Yup.string().required('Designation is required'),

      // Similar validations for other employment history fields
    })
  ),
});

const EditEmployeeForm = ({ initialValues }) => {

  const handleSubmit = async (values) => {
    try {
      // Send the values to your JSON server
      // Make an Axios request to update the employee's data
      
      await axios.put(`http://localhost:8000/employees/${initialValues.id}`, values); // Replace with your API endpoint

      // Handle success (e.g., show a success message)
      console.log('Employee data updated successfully');
      alert('Employee details submitted successfully!');
    } catch (error) {
      console.error('Error submitting employee details:', error);
    }
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ values, handleSubmit }) => (
        <>
        <Form>
          <h2>Edit Employee Details</h2>

          {/* Personal Details */}
          <h3>Personal Details</h3>
          <div className="form-group">
            <label htmlFor="firstName">First Name:</label>
            <Field type="text" id="firstName" name="firstName" className="form-control" />
            <ErrorMessage name="firstName" component="div" className="text-danger" />
          </div>
          {/* Add fields for lastName, email, contact, aadharNumber, etc. */}
          {/* ...

          {/* Education Details */}
          <h3>Education Details</h3>
          <FieldArray name="education">
            {({ push, remove }) => (
              <>
                {values.education.map((edu, index) => (
                  <div key={index}>
                    <h4>Education Entry #{index + 1}</h4>
                    <div className="form-group">
                      <label htmlFor={`education[${index}].sscSchool`}>SSC School:</label>
                      <Field type="text" id={`education[${index}].sscSchool`} name={`education[${index}].sscSchool`} className="form-control" />
                      <ErrorMessage name={`education[${index}].sscSchool`} component="div" className="text-danger" />
                    </div>
                    {/* Add fields for other education details */}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    push({
                      sscSchool: '',
                      sscUniversity: '',
                      sscPassingYear: '',
                      sscPercentage: '',
                    });
                  }}
                >
                  Add Education Entry
                </button>
              </>
            )}
          </FieldArray>

          {/* Employment History */}
          <h3>Employment History</h3>
          <FieldArray name="employmentHistory">
            {({ push, remove }) => (
              <>
                {values.employmentHistory.map((emp, index) => (
                  <div key={index}>
                    <h4>Employment History Entry #{index + 1}</h4>
                    <div className="form-group">
                      <label htmlFor={`employmentHistory[${index}].companyName`}>Company Name:</label>
                      <Field type="text" id={`employmentHistory[${index}].companyName`} name={`employmentHistory[${index}].companyName`} className="form-control" />
                      <ErrorMessage name={`employmentHistory[${index}].companyName`} component="div" className="text-danger" />
                    </div>
                    {/* Add fields for other employment history details */}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    push({
                      companyName: '',
                      location: '',
                      fromDate: '',
                      toDate: '',
                      designation: '',
                    });
                  }}
                >
                  Add Employment History Entry
                </button>
              </>
            )}
          </FieldArray>

          <button type="submit" className="btn btn-primary" onClick={handleSubmit}>
            Save Changes
          </button>
        </Form>
        </>
      )}
    </Formik>
  )}

  export default EditEmployeeForm