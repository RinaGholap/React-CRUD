import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Modal from 'react-modal'; // Import the modal library

Modal.setAppElement('#root'); // Set the root element for accessibility

const customStyles = {
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  content: {
    top: '10%',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '300px',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.2)',
  },
};

const validationSchema = Yup.object({
  name: Yup.string().required('Name is required'),
});

const Home = () => {
  const [items, setItems] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false); // State to control the modal
  // const [showConfirmation, setShowConfirmation] = useState(false); // State to show the confirmation
  const [itemToDelete, setItemToDelete] = useState(null); // Store the item to delete

  useEffect(() => {
    fetch('http://localhost:8000/employees')
      .then((response) => response.json())
      .then((data) => setItems(data));
  }, []);

  const handleDelete = (item) => {
    setItemToDelete(item); // Store the item to delete
    setModalIsOpen(true); // Open the modal
    // setShowConfirmation(true); // Show the confirmation
  };

  // const handleDelete = (id) => {
  //   fetch(`http://localhost:8000/employees/${id}`, {
  //     method: 'DELETE',
  //   }).then(() => {
  //     setItems(items.filter((item) => item.id !== id));
  //     setSelectedItem(null);
  //   });
  // };

  const confirmDelete = () => {
    if (itemToDelete) {
      console.log("itemToDelete", itemToDelete);
      fetch(`http://localhost:8000/employees/${itemToDelete}`, {
        method: 'DELETE',
      })
        .then((response) => {
          if (response.ok) {
            // Item deleted successfully
            console.log(`Item with ID ${itemToDelete} deleted successfully.`);
            setItems(items.filter((item) => item.id !== itemToDelete));
            setModalIsOpen(false);
            toast.success('Item deleted successfully', {
              position: 'top-right',
              autoClose: 3000,
            });
          } else {
            // Item deletion failed
            console.error(`Failed to delete item with ID ${itemToDelete}.`);
            setModalIsOpen(false);
          }
        })
        .catch((error) => {
          console.error('Error deleting item:', error);
          setModalIsOpen(false);
        });
    }
  };
  


  const handleSubmit = (values) => {
    if (selectedItem) {
      // Update existing item
      fetch(`http://localhost:8000/employees/${selectedItem.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      }).then(() => {
        setItems((prevItems) =>
          prevItems.map((item) =>
            item.id === selectedItem.id ? { ...item, ...values } : item
          )
        );
        setSelectedItem(null);
      });
    } else {
      // Create new item
      fetch('http://localhost:8000/employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      }).then(() => {
        setItems((prevItems) => [...prevItems, { ...values, id: Date.now() }]);
      });
    }
  };

  
  return (
    <>
      <div className="container justify-content-center">
        <h1>Item List</h1><br />
        <table className="table table-responsive">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>
                  <Link to={`/view/${item.id}`} className="btn btn-success">View</Link>{' '}
                  <Link to={`/edit/${item.id}`} className="btn btn-primary">Edit</Link>{' '}
                  <button onClick={() => handleDelete(item.id)} className="btn btn-danger">Delete</button>
                </td>
                <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        style={customStyles}
        contentLabel="Delete Confirmation"
      >
        <h2>Confirm Delete</h2>
        <p>Are you sure you want to delete this item?</p>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <button onClick={confirmDelete}>Yes</button>
          <button onClick={() => setModalIsOpen(false)}>No</button>
        </div>
      </Modal> <ToastContainer />
              </tr>
              
            ))}
          </tbody>
        </table>
        <Link to="/create" className="btn btn-success">Create New Item</Link>
        {/* {showConfirmation && (
        <div className="confirmation">
          <h2>Confirm Delete</h2>
          <p>Are you sure you want to delete this item?</p>
          <button onClick={confirmDelete}>Yes</button>
          <button onClick={() => setShowConfirmation(false)}>No</button>
        </div>
      )} */}

    

      </div>

      {/* Modal for confirmation */}
      {/* <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        contentLabel="Delete Confirmation"
        className="custom-modal" // Apply a custom CSS class for styling
        overlayClassName="custom-modal-overlay" // Apply a custom CSS class for the modal overlay
      >
        <div className="modal-content">
          <h2>Confirm Delete</h2>
          <p>Are you sure you want to delete this item?</p>
          <button className="btn-confirm" onClick={confirmDelete}>Yes</button>
          <button className="btn-cancel" onClick={() => setModalIsOpen(false)}>No</button>
        </div>
      </Modal> */}
    </>
  );
};

export default Home;
