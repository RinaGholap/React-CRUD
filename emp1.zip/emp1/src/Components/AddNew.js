// src/components/AddEmployeeForm.js
import React from 'react';
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  contact: Yup.string().required('Contact is required'),
  aadharNumber: Yup.string().required('Aadhar Number is required'),

  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      sscPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('SSC Passing Year is required'),
      sscPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('SSC Percentage is required'),
      hscDiplomaCollege: Yup.string().required('HSC/Diploma College is required'),
      hscDiplomaUniversity: Yup.string().required('HSC/Diploma University is required'),
      hscDiplomaPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('HSC/Diploma Passing Year is required'),
      hscDiplomaPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('HSC/Diploma Percentage is required'),
      graduationCollege: Yup.string().required('Graduation College is required'),
      graduationUniversity: Yup.string().required('Graduation University is required'),
      graduationPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('Graduation Passing Year is required'),
      graduationPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('Graduation Percentage is required'),
    })
  ),
  employmentHistory: Yup.array().of(
    Yup.object().shape({
      companyName: Yup.string().required('Company Name is required'),
      location: Yup.string().required('Location is required'),
      fromDate: Yup.date().required('From Date is required'),
      toDate: Yup.date().required('To Date is required'),
      designation: Yup.string().required('Designation is required'),
    })
  ),
});

const AddNew = () => {
  const handleSubmit = async (values) => {
    try {
      // Send the values to your JSON server
      await axios.post('http://localhost:8000/employees', values);
      alert('Employee details submitted successfully!');
    } catch (error) {
      console.error('Error submitting employee details:', error);
    }
  };

  return (
    <Formik
      initialValues={{
        firstName: '',
        lastName: '',
        email: '',
        contact: '',
        aadharNumber: '',
        education: [
          {
            sscSchool: '',
            sscUniversity: '',
            sscPassingYear: '',
            sscPercentage: '',
            hscDiplomaCollege: '',
            hscDiplomaUniversity: '',
            hscDiplomaPassingYear: '',
            hscDiplomaPercentage: '',
            graduationCollege: '',
            graduationUniversity: '',
            graduationPassingYear: '',
            graduationPercentage: '',
          },
        ],
        employmentHistory: [
          {
            companyName: '',
          location: '',
          fromDate: '',
          toDate: '',
          designation: '',
          },
        ],
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >{({ values, setValues }) => (
      <Form>

        {/* Education Details */}
        <h3>Education Details</h3>
        <FieldArray name="education">
          {({ push, remove }) => (
            <>
              {values.education.map((education, index) => (
                <div key={index}>
                  <h4>Education Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`education[${index}].sscSchool`}>SSC School:</label>
                    <Field type="text" id={`education[${index}].sscSchool`} name={`education[${index}].sscSchool`} className="form-control" />
                    <ErrorMessage name={`education[${index}].sscSchool`} component="div" className="text-danger" />
                  </div>
                  {/* Add more education fields here, naming them accordingly */}
                  <div className="form-group">
                    <label htmlFor={`education[${index}].sscUniversity`}>SSC University:</label>
                    <Field type="text" id={`education[${index}].sscUniversity`} name={`education[${index}].sscUniversity`} className="form-control" />
                    <ErrorMessage name={`education[${index}].sscUniversity`} component="div" className="text-danger" />
                  </div>
                  {/* Add similar fields for other education details (sscPassingYear, sscPercentage, etc.) */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    sscSchool: '',
                    sscUniversity: '',
                    // Add initial values for other education fields
                    // ...
                  })
                }
              >
                Add Education Entry
              </button>
            </>
          )}
        </FieldArray>

        {/* Employment History */}
        <h3>Employment History</h3>
        <FieldArray name="employmentHistory">
          {({ push, remove }) => (
            <>
              {values.employmentHistory.map((history, index) => (
                <div key={index}>
                  <h4>Employment History Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].companyName`}>Company Name:</label>
                    <Field type="text" id={`employmentHistory[${index}].companyName`} name={`employmentHistory[${index}].companyName`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].companyName`} component="div" className="text-danger" />
                  </div>
                  {/* Add more employment history fields here, naming them accordingly */}
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].location`}>Location:</label>
                    <Field type="text" id={`employmentHistory[${index}].location`} name={`employmentHistory[${index}].location`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].location`} component="div" className="text-danger" />
                  </div>

                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].fromDate`}>from Date:</label>
                    <Field type="date" id={`employmentHistory[${index}].fromDate`} name={`employmentHistory[${index}].fromDate`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].fromDate`} component="div" className="text-danger" />
                  </div>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].toDate`}>to Date:</label>
                    <Field type="date" id={`employmentHistory[${index}].toDate`} name={`employmentHistory[${index}].toDate`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].toDate`} component="div" className="text-danger" />
                  </div>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].designation`}>Designation:</label>
                    <Field type="text" id={`employmentHistory[${index}].designation`} name={`employmentHistory[${index}].designation`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].designation`} component="div" className="text-danger" />
                  </div>
                  <button type="button" onClick={() => remove(index)}>
                    Remove
                  </button>
                  {/* Add similar fields for other employment history details (fromDate, toDate, designation, etc.) */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    companyName: '',
                    location: '',
                    // Add initial values for other employment history fields
                    // ...
                  })
                }
              >
                Add Employment History Entry
              </button>
            </>
          )}
        </FieldArray>

        <button type="submit" className="btn btn-primary">Submit</button>
      </Form>
    )}</Formik>
  )
}

export default AddNew
