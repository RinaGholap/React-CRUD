import React from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import * as Yup from 'yup'
import axios from 'axios'

const validationSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  contact: Yup.string().required('Contact is required'),
  aadharNumber: Yup.string().required('Aadhar Number is required'),
})

const AddEmployeePersonalDetails = () => {
  const handleSubmit = async (values) => {
    try {
      await axios.post('http://localhost:8000/employees', values); // Assuming JSON Server runs on port 3000
      alert('Application submitted successfully!');
    } catch (error) {
      console.error('Error submitting application:', error);
    }
  };

  return (
    <>AddEmployeePersonalDetails
          <Formik
      initialValues={{
        firstName: '',
        lastName: '',
        email: '',
        contact: '',
        aadharNumber: '',
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      <Form>
        <div>
          <label htmlFor="firstName">First Name:</label>
          <Field type="text" id="firstName" name="firstName" />
          <ErrorMessage name="firstName" component="div" />
        </div>
        <div>
          <label htmlFor="lastName">Last Name:</label>
          <Field type="text" id="lastName" name="lastName" />
          <ErrorMessage name="lastName" component="div" />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <Field type="email" id="email" name="email" />
          <ErrorMessage name="email" component="div" />
        </div>
        <div>
          <label htmlFor="contact">Contact:</label>
          <Field type="text" id="contact" name="contact" />
          <ErrorMessage name="contact" component="div" />
        </div>
        <div>
          <label htmlFor="aadharNumber">Aadhar Number:</label>
          <Field type="text" id="aadharNumber" name="aadharNumber" />
          <ErrorMessage name="aadharNumber" component="div" />
        </div>
        <button type="submit">Submit</button>
      </Form>
    </Formik>
    </>
  )
}

export default AddEmployeePersonalDetails