import React from 'react'
import { Formik, Form, Field, ErrorMessage, FieldArray} from 'formik'
import * as Yup from 'yup'
import axios from 'axios'

const validationSchema = Yup.object().shape({
  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      sscPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('SSC Passing Year is required'),
      sscPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('SSC Percentage is required'),
      hscDiplomaCollege: Yup.string().required('HSC/Diploma College is required'),
      hscDiplomaUniversity: Yup.string().required('HSC/Diploma University is required'),
      hscDiplomaPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('HSC/Diploma Passing Year is required'),
      hscDiplomaPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('HSC/Diploma Percentage is required'),
      graduationCollege: Yup.string().required('Graduation College is required'),
      graduationUniversity: Yup.string().required('Graduation University is required'),
      graduationPassingYear: Yup.number()
        .typeError('Passing year must be a number')
        .required('Graduation Passing Year is required'),
      graduationPercentage: Yup.number()
        .typeError('Percentage must be a number')
        .required('Graduation Percentage is required'),
    })
  ),
})

const AddEmployeeEducationDetails = ({ employeeId }) => {

  const handleSubmit = async (values) => {
    try {
      await axios.post('http://localhost:8000/employees', values); // Assuming JSON Server runs on port 3000
      alert('Application submitted successfully!');
    } catch (error) {
      console.error('Error submitting application:', error);
    }
  };

  return (
    <>AddEmployeeEducationDetails
         <Formik
      initialValues={{
        education: [
          {
            sscSchool: '',
            sscUniversity: '',
            sscPassingYear: '',
            sscPercentage: '',
            hscDiplomaCollege: '',
            hscDiplomaUniversity: '',
            hscDiplomaPassingYear: '',
            hscDiplomaPercentage: '',
            graduationCollege: '',
            graduationUniversity: '',
            graduationPassingYear: '',
            graduationPercentage: '',
          },
        ],
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ values }) => (
        <Form>
          {/* ... Previous form fields ... */}
          <FieldArray
            name="education"
            render={(arrayHelpers) => (
              <div>
                <h2>Education Details</h2>
                {values.education.map((edu, index) => (
                  <div key={index}>
                    <h3>Education #{index + 1}</h3>
                    <div>
                      <label htmlFor={`education[${index}].sscSchool`}>SSC School:</label>
                      <Field type="text" id={`education[${index}].sscSchool`} name={`education[${index}].sscSchool`} />
                      <ErrorMessage name={`education[${index}].sscSchool`} component="div" />
                    </div>
                    <div>
                      <label htmlFor={`education[${index}].sscUniversity`}>sscUniversity:</label>
                      <Field type="text" id={`education[${index}].sscUniversity`} name={`education[${index}].sscUniversity`} />
                      <ErrorMessage name={`education[${index}].sscUniversity`} component="div" />
                    </div>
                    <div>
                      <label htmlFor={`education[${index}].sscPassingYear`}>sscPassingYear:</label>
                      <Field type="text" id={`education[${index}].sscPassingYear`} name={`education[${index}].sscPassingYear`} />
                      <ErrorMessage name={`education[${index}].sscPassingYear`} component="div" />
                    </div>
                    <div>
                      <label htmlFor={`education[${index}].sscPercentage`}>sscPercentage:</label>
                      <Field type="text" id={`education[${index}].sscPercentage`} name={`education[${index}].sscPercentage`} />
                      <ErrorMessage name={`education[${index}].sscPercentage`} component="div" />
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => arrayHelpers.push({ sscSchool: '',
                  sscUniversity: '',
                  sscPassingYear: '',
                  sscPercentage: '' })}
                >
                  Add Education
                </button>
              </div>
            )}
          />
          <div>
            <button type="submit">Submit</button>
          </div>
        </Form>
      )}
    </Formik>
    </>
  )
}

export default AddEmployeeEducationDetails