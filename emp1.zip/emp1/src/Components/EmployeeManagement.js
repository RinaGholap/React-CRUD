import React, { useState, useEffect } from 'react'
import axios from 'axios'
import AddEmployeeEducationDetails from './EmployeeEducationDetails/AddEmployeeEducationDetails'
import AddEmployeeHistoryDetails from './EmployeeHistoryDetails/AddEmployeeHistoryDetails'
import AddEmployeePersonalDetails from './EmployeePersonalDetails/AddEmployeePersonalDetails'
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Modal from 'react-modal'; // Import the modal library
import AddNew from './AddNew'
import EditEmployeeDetails from './EditEmployeeDetails'
import EditEmployeeForm from './EditEmployeeForm'
import ReactDOM from 'react-dom';


const EmployeeManagement = () => {

  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  // Fetch employee data from the JSON server
  useEffect(() => {
    axios.get('http://localhost:8000/employees')
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error('Error fetching employee data:', error);
      });
  }, []);

  const navigate = useNavigate();

  // const viewEmp =(id) =>{
  //   navigate('/edit/:id')
  // }
  const [isEditing, setIsEditing] = useState(false);
  const [editEmployeeData, setEditEmployeeData] = useState(null);

  const handleEditClick = (employeeData) => {
    console.log("in edit");
    setEditEmployeeData(employeeData);
    setIsEditing(true);
    // openEditFormInNewWindow(); // Call the function to open the form in a new window
  };

 


  const handleHistoryAdded = () => {
    // Reload the employee data after history details are added
    axios.get('http://localhost:8000/employees')
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error('Error fetching updated employee data:', error);
      });
  };

  const handleEmployeeSelect = (employee) => {
    setSelectedEmployee(employee);
  };

  return (
    <>
      EmployeeManagement

      <div>
      {isEditing ? (
        <EditEmployeeForm
          initialValues={editEmployeeData}
          // onClose={handleFormClose}
        />
      ) : (
        <>
        <h1>Employee Management</h1><br />
        <AddNew />
        <br />
    <div className="container mt-4">
      <h2 className="mb-3">Employee List</h2>
      <table className="table table-bordered table-striped">
        <thead className="thead-dark">
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Aadhar Number</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          
          {employees.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{`${employee.firstName} ${employee.lastName}`}</td>
              <td>{employee.email}</td>
              <td>{employee.contact}</td>
              <td>{employee.aadharNumber}</td>
              <td> 
              {/* <button onClick={() => viewEmp(`${employee.id}`)}>Edit</button> */}
                {/* <Link to={`/view/${employee.id}`} className="btn btn-success">View</Link>{' '} */}
                  {/* <Link to={`/edit/${employee.id}`} className="btn btn-primary">Edit</Link>{' '} */}
                  <button onClick={() => handleEditClick(employee)}>Edit</button>
                  </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Education Details</h2>
      {employees.map((employee) => (
        <div  className="table-responsive" key={employee.id}>
          <h3 className="mt-4">{`${employee.firstName} ${employee.lastName}`}</h3>
          <table className="table table-bordered">
            <thead className="thead-light">
              <tr>
                <th>SSC School</th>
                <th>SSC University</th>
                <th>SSC Passing Year</th>
                <th>SSC Percentage</th>
                <th>HSC/Diploma College</th>
                <th>HSC/Diploma University</th>
                <th>HSC/Diploma Passing Year</th>
                <th>HSC/Diploma Percentage</th>
                <th>Graduation College</th>
                <th>Graduation University</th>
                <th>Graduation Passing Year</th>
                <th>Graduation Percentage</th>
              </tr>
            </thead>
            <tbody>

            {employee.education?.map((edu, index) => (
                <tr key={index}>
                  <td>{edu.sscSchool}</td>
                  <td>{edu.sscUniversity}</td>
                  <td>{edu.sscPassingYear}</td>
                  <td>{edu.sscPercentage}</td>
                  <td>{edu.hscDiplomaCollege}</td>
                  <td>{edu.hscDiplomaUniversity}</td>
                  <td>{edu.hscDiplomaPassingYear}</td>
                  <td>{edu.hscDiplomaPercentage}</td>
                  <td>{edu.graduationCollege}</td>
                  <td>{edu.graduationUniversity}</td>
                  <td>{edu.graduationPassingYear}</td>
                  <td>{edu.graduationPercentage}</td>
                </tr>
              ))}
              <tr>
                
              </tr>
            </tbody>
          </table>
        </div>
      ))}

      <h2 className="mt-4">Employment History</h2>
      {employees.map((employee) => (
        <div className="table-responsive" key={employee.id}>
          <h3>{`${employee.firstName} ${employee.lastName}`}</h3>
          <table className="table table-bordered table-striped">
            <thead className="thead-light">
              <tr>
                <th>Company Name</th>
                <th>Location</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Designation</th>
              </tr>
            </thead>
            <tbody>
              {employee.employmentHistory?.map((history, index) => (
                <tr key={index}>
                  <td>{history.companyName}</td>
                  <td>{history.location}</td>
                  <td>{history.fromDate}</td>
                  <td>{history.toDate}</td>
                  <td>{history.designation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>




        <div>
          {/* <AddEmployeePersonalDetails /> */}
          {/* <AddEmployeeEducationDetails /> */}
          {/* <AddEmployeeHistoryDetails /> */}
          {/* <ul>
          {employees.map((employee) => (
            <li key={employee.id}>
              {employee.firstName} {employee.lastName}
              <button onClick={() => handleEmployeeSelect(employee)}>Select</button>
            </li>
          ))}
        </ul> */}
        </div>

        {/* {selectedEmployee && (
        <div>
          <h2>Selected Employee</h2>
          <h3>{selectedEmployee.firstName} {selectedEmployee.lastName}</h3> */}
        {/* Render EducationDetailsForm and HistoryDetailsForm components here */}
        {/* <AddEmployeeEducationDetails employeeId={selectedEmployee.id} />
          <AddEmployeeHistoryDetails employeeId={selectedEmployee.id} onHistoryAdded={handleHistoryAdded} />
        </div>
      )} */}

        <div>
          {/* <h2>Add New Employee</h2> */}
          {/* <AddEmployeePersonalDetails /> */}
        </div>

        {/* {editEmployeeData && (
          navigate(<EditEmployeeForm
            initialValues={editEmployeeData}
            onClose={() => setEditEmployeeData(null)
            }
          />)
        
      )} */}
      </>
      )}
      </div>
      
    </>
  )
}

export default EmployeeManagement