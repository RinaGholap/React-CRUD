// src/components/AddEmployeeForm.js
import React from 'react';
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  contact: Yup.string().required('Contact is required'),
  aadharNumber: Yup.number()
    .typeError('Aadhar Number must be a number')
    .required('Aadhar Number is required'),
  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      sscPassingYear: Yup.number()
        .typeError('SSC Passing Year must be a number')
        .required('SSC Passing Year is required'),
      sscPercentage: Yup.number()
        .typeError('SSC Percentage must be a number')
        .required('SSC Percentage is required'),
      hscDiplomaCollege: Yup.string().required('HSC/Diploma College is required'),
      hscDiplomaUniversity: Yup.string().required('HSC/Diploma University is required'),
      hscDiplomaPassingYear: Yup.number()
        .typeError('HSC/Diploma Passing Year must be a number')
        .required('HSC/Diploma Passing Year is required'),
      hscDiplomaPercentage: Yup.number()
        .typeError('HSC/Diploma Percentage must be a number')
        .required('HSC/Diploma Percentage is required'),
      graduationCollege: Yup.string().required('Graduation College is required'),
      graduationUniversity: Yup.string().required('Graduation University is required'),
      graduationPassingYear: Yup.number()
        .typeError('Graduation Passing Year must be a number')
        .required('Graduation Passing Year is required'),
      graduationPercentage: Yup.number()
        .typeError('Graduation Percentage must be a number')
        .required('Graduation Percentage is required'),
    })
  ),
  employmentHistory: Yup.array().of(
    Yup.object().shape({
      companyName: Yup.string().required('Company Name is required'),
      location: Yup.string().required('Location is required'),
      fromDate: Yup.date().required('From Date is required'),
      toDate: Yup.date().required('To Date is required'),
      designation: Yup.string().required('Designation is required'),
    })
  ),
});

const AddEmployeeForm = () => {
  const handleSubmit = async (values) => {
    try {
      // Send the values to your JSON server
      await axios.post('http://localhost:3000/employees', values);
      alert('Employee details submitted successfully!');
    } catch (error) {
      console.error('Error submitting employee details:', error);
    }
  };

  return (
    <Formik
      initialValues={{
        firstName: '',
        lastName: '',
        email: '',
        contact: '',
        aadharNumber: '',
        education: [
          {
            sscSchool: '',
            sscUniversity: '',
            sscPassingYear: '',
            sscPercentage: '',
            hscDiplomaCollege: '',
            hscDiplomaUniversity: '',
            hscDiplomaPassingYear: '',
            hscDiplomaPercentage: '',
            graduationCollege: '',
            graduationUniversity: '',
            graduationPassingYear: '',
            graduationPercentage: '',
          },
        ],
        employmentHistory: [
          {
            companyName: '',
            location: '',
            fromDate: '',
            toDate: '',
            designation: '',
          },
        ],
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      <Form>
        {/* Personal Details */}
        <h3>Personal Details</h3>
        <div className="form-group">
          <label htmlFor="firstName">First Name:</label>
          <Field type="text" id="firstName" name="firstName" className="form-control" />
          <ErrorMessage name="firstName" component="div" className="text-danger" />
        </div>
        <div>
          <label htmlFor="lastName">Last Name:</label>
          <Field type="text" id="lastName" name="lastName" />
          <ErrorMessage name="lastName" component="div" />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <Field type="email" id="email" name="email" />
          <ErrorMessage name="email" component="div" />
        </div>
        <div>
          <label htmlFor="contact">Contact:</label>
          <Field type="text" id="contact" name="contact" />
          <ErrorMessage name="contact" component="div" />
        </div>
        <div>
          <label htmlFor="aadharNumber">Aadhar Number:</label>
          <Field type="text" id="aadharNumber" name="aadharNumber" />
          <ErrorMessage name="aadharNumber" component="div" />
        </div>

        {/* Education Details */}
        <h3>Education Details</h3>
        <div className="form-group">
          <label htmlFor="firstName">First Name:</label>
          <Field type="text" id="firstName" name="firstName" className="form-control" />
          <ErrorMessage name="firstName" component="div" className="text-danger" />
        </div>


        {/* Employment History */}
        <h3>Employment History</h3>
        <FieldArray name="employmentHistory">
          {({ push, remove }) => (
            <>
              {values.employmentHistory.map((_, index) => (
                <div key={index}>
                  {/* Employment history fields */}
                  {/* Add more employment history fields here */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    companyName: '',
                    location: '',
                    fromDate: '',
                    toDate: '',
                    designation: '',
                  })
                }
              >
                Add Employment History
              </button>
            </>
          )}
        </FieldArray>

        <button type="submit" className="btn btn-primary">Submit</button>
      </Form>
    </Formik>
  );
};

export default AddEmployeeForm;
