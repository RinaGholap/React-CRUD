import logo from './logo.svg';
import './App.css';
import EmployeeManagement from './Components/EmployeeManagement';
import Home from './Components/Home';
import EditEmployee from './Components/EditEmployeeDetails';
import { Route, Routes } from 'react-router-dom';
import Header from './Components/Header';
import EditEmployeeForm from './Components/EditEmployeeForm';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      {/* <Home /> */}
      <Header />
      {/* <EmployeeManagement /> */}

      
      <Routes >
         {/* Default route (home page) */}
        <Route path="/" element={<EmployeeManagement />} />
        {/* Route for creating a new item */}
        {/* <Route path="/create" element={<CreateItem />} /> */}
         {/* Route for editing an existing item */}
        <Route path="/edit/:id" element={<EditEmployeeForm />} />
        {/* <Route path="/view/:id" element={<ViewItem />} /> */}
      </Routes>
      
    </div>
  );
}

export default App;
