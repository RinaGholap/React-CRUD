// src/components/AddEmployeeForm.js
import React from 'react';
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const validationSchema = Yup.object().shape({
  // Validation schema for personal details (firstName, lastName, etc.) remains the same as mentioned earlier
  // ...

  education: Yup.array().of(
    Yup.object().shape({
      sscSchool: Yup.string().required('SSC School is required'),
      sscUniversity: Yup.string().required('SSC University is required'),
      // Add validation for other education fields (sscPassingYear, sscPercentage, etc.)
      // ...

      // Rename the fields according to your preference
    })
  ),
  employmentHistory: Yup.array().of(
    Yup.object().shape({
      companyName: Yup.string().required('Company Name is required'),
      location: Yup.string().required('Location is required'),
      // Add validation for other employment history fields (fromDate, toDate, designation, etc.)
      // ...

      // Rename the fields according to your preference
    })
  ),
});

const AddNew = () => {
  const handleSubmit = async (values) => {
    try {
      // Send the values to your JSON server
      await axios.post('http://localhost:8000/employees', {
        // Map the form values to match your JSON structure
        // firstName: values.firstName,
        // lastName: values.lastName,
        // email: values.email,
        // contact: values.contact,
        // aadharNumber: parseInt(values.aadharNumber),
        // education: values.education,
        employmentHistory: values.employmentHistory,
      });
      alert('Employee details submitted successfully!');
    } catch (error) {
      console.error('Error submitting employee details:', error);
    }
  };

  return (
    <Formik
      initialValues={{
        // Initial values for personal details (firstName, lastName, etc.) remain the same as mentioned earlier
        // ...

        education: [
          {
            sscSchool: '',
            sscUniversity: '',
            // Add initial values for other education fields
            // ...
          },
        ],
        employmentHistory: [
          {
            companyName: '',
            location: '',
            // Add initial values for other employment history fields
            // ...
          },
        ],
      }}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >{({ values, setValues }) => (
      <Form>
        {/* The form fields for personal details */}
        {/* ...

        {/* Education Details */}
        <h3>Education Details</h3>
        <FieldArray name="education">
          {({ push, remove }) => (
            <>
              {values.education.map((education, index) => (
                <div key={index}>
                  <h4>Education Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`education[${index}].sscSchool`}>SSC School:</label>
                    <Field type="text" id={`education[${index}].sscSchool`} name={`education[${index}].sscSchool`} className="form-control" />
                    <ErrorMessage name={`education[${index}].sscSchool`} component="div" className="text-danger" />
                  </div>
                  {/* Add more education fields here, naming them accordingly */}
                  <div className="form-group">
                    <label htmlFor={`education[${index}].sscUniversity`}>SSC University:</label>
                    <Field type="text" id={`education[${index}].sscUniversity`} name={`education[${index}].sscUniversity`} className="form-control" />
                    <ErrorMessage name={`education[${index}].sscUniversity`} component="div" className="text-danger" />
                  </div>
                  {/* Add similar fields for other education details (sscPassingYear, sscPercentage, etc.) */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    sscSchool: '',
                    sscUniversity: '',
                    // Add initial values for other education fields
                    // ...
                  })
                }
              >
                Add Education Entry
              </button>
            </>
          )}
        </FieldArray>

        {/* Employment History */}
        <h3>Employment History</h3>
        <FieldArray name="employmentHistory">
          {({ push, remove }) => (
            <>
              {values.employmentHistory.map((history, index) => (
                <div key={index}>
                  <h4>Employment History Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].companyName`}>Company Name:</label>
                    <Field type="text" id={`employmentHistory[${index}].companyName`} name={`employmentHistory[${index}].companyName`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].companyName`} component="div" className="text-danger" />
                  </div>
                  {/* Add more employment history fields here, naming them accordingly */}
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].location`}>Location:</label>
                    <Field type="text" id={`employmentHistory[${index}].location`} name={`employmentHistory[${index}].location`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].location`} component="div" className="text-danger" />
                  </div>

                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].fromDate`}>from Date:</label>
                    <Field type="date" id={`employmentHistory[${index}].fromDate`} name={`employmentHistory[${index}].fromDate`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].fromDate`} component="div" className="text-danger" />
                  </div>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].toDate`}>to Date:</label>
                    <Field type="date" id={`employmentHistory[${index}].toDate`} name={`employmentHistory[${index}].toDate`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].toDate`} component="div" className="text-danger" />
                  </div>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].designation`}>Designation:</label>
                    <Field type="text" id={`employmentHistory[${index}].designation`} name={`employmentHistory[${index}].designation`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].designation`} component="div" className="text-danger" />
                  </div>
                  <button type="button" onClick={() => remove(index)}>
                    Remove
                  </button>
                  {/* Add similar fields for other employment history details (fromDate, toDate, designation, etc.) */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    companyName: '',
                    location: '',
                    // Add initial values for other employment history fields
                    // ...
                  })
                }
              >
                Add Employment History Entry
              </button>
            </>
          )}
        </FieldArray>

        <button type="submit" className="btn btn-primary">Submit</button>
      </Form>
    )}</Formik>
  )}
  
  export default AddNew
