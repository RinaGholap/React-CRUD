import React from 'react'

function Home() {
  return (
    <> 
      <h1>Job Application System</h1>
    
    </>
  )
}

export default Home