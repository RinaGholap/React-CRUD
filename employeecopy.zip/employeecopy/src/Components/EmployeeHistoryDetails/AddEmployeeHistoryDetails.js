import React from 'react'
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik'
import * as Yup from 'yup'
import axios from 'axios'

const validationSchema = Yup.object().shape({
  companyName: Yup.string().required('Company Name is required'),
  location: Yup.string().required('Location is required'),
  fromDate: Yup.date().required('From Date is required'),
  toDate: Yup.date().required('To Date is required'),
  designation: Yup.string().required('Designation is required'),
})

const AddEmployeeHistoryDetails = () => {

  const handleSubmit = async (values, { resetForm }) => {
    try {
      // Create a new history object
      // const newHistory = 
      // {
      //   employmentHistory: [{
      //     companyName: values.companyName,
      //     location: values.location,
      //     fromDate: values.fromDate,
      //     toDate: values.toDate,
      //     designation: values.designation,
      //   }]
      // }

      // Send the new history object to your JSON server
      await axios.post(`http://localhost:8000/employees/`, {
        
          // Map the form values to match your JSON structure
          // firstName: values.firstName,
          // lastName: values.lastName,
          // email: values.email,
          // contact: values.contact,
          // aadharNumber: parseInt(values.aadharNumber),
          // education: values.education,
          employmentHistory: values.employmentHistory,
        
      });
      alert('Application submitted successfully!');
      // resetForm(); // Reset the form fields
      // onHistoryAdded(); // Trigger a callback to inform the parent component
    } catch (error) {
      console.error('Error adding history details:', error);
    }
  }

  return (
    <>
      AddEmployeeHistoryDetails
      <div>
      <h2>Add Employee History Details</h2>
      <Formik
        initialValues={{
          employmentHistory: [{
          companyName: '',
          location: '',
          fromDate: '',
          toDate: '',
          designation: '',
        }]
      }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      > {({ values, setValues }) => (
        <Form>
          {/* Employment History */}
        <h3>Employment History</h3>
        <FieldArray name="employmentHistory">
          {({ push, remove }) => (
            <>
              {values.employmentHistory.map((history, index) => (
                <div key={index}>
                  <h4>Employment History Entry #{index + 1}</h4>
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].companyName`}>Company Name:</label>
                    <Field type="text" id={`employmentHistory[${index}].companyName`} name={`employmentHistory[${index}].companyName`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].companyName`} component="div" className="text-danger" />
                  </div>
                  {/* Add more employment history fields here, naming them accordingly */}
                  <div className="form-group">
                    <label htmlFor={`employmentHistory[${index}].location`}>Location:</label>
                    <Field type="text" id={`employmentHistory[${index}].location`} name={`employmentHistory[${index}].location`} className="form-control" />
                    <ErrorMessage name={`employmentHistory[${index}].location`} component="div" className="text-danger" />
                  </div>
                  {/* Add similar fields for other employment history details (fromDate, toDate, designation, etc.) */}
                </div>
              ))}
              <button
                type="button"
                onClick={() =>
                  push({
                    companyName: '',
                    location: '',
                    // Add initial values for other employment history fields
                    // ...
                  })
                }
              >
                Add Employment History Entry
              </button>
            </>
          )}
        </FieldArray>


          {/* <div>
            <label htmlFor="companyName">Company Name:</label>
            <Field type="text" id="companyName" name="companyName" />
            <ErrorMessage name="companyName" component="div" />
          </div>
          <div>
            <label htmlFor="location">Location:</label>
            <Field type="text" id="location" name="location" />
            <ErrorMessage name="location" component="div" />
          </div>
          <div>
            <label htmlFor="fromDate">From Date:</label>
            <Field type="date" id="fromDate" name="fromDate" />
            <ErrorMessage name="fromDate" component="div" />
          </div>
          <div>
            <label htmlFor="toDate">To Date:</label>
            <Field type="date" id="toDate" name="toDate" />
            <ErrorMessage name="toDate" component="div" />
          </div>
          <div>
            <label htmlFor="designation">Designation:</label>
            <Field type="text" id="designation" name="designation" />
            <ErrorMessage name="designation" component="div" />
          </div> */}
          <button type="submit">Submit</button>
        </Form>
      )}</Formik>
    </div>
    </>
  )
}

export default AddEmployeeHistoryDetails