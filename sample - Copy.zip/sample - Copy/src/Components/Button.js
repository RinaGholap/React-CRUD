import React from "react";

const Button = props => {
  const btnEnableDisable = !props.isDisabled ? "btn-enable" : "btn-disabled";

  return (
    <button
      id={props.id}
      className={`btn ${props.className}`}
      onClick={props.clickHandler}
      type={props.type}
      disabled={props.isDisabled}
      style={props.style}
    >
      {props.value}
    </button>
  );
};

Button.defaultProps = {
  type: "button",

  disabled: false
};

export default Button;