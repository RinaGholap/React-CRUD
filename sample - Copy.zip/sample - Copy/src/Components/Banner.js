import React, { Component } from 'react'
import Button from './Button'
import Login from './Login/Login';

export class Banner extends Component {
  constructor(props) {
    super(props)

    this.state = {
      content: ''
    }
  }

  render() {
    var style = { 'border-radius': 30, 'width': 100, 'margin-right': 20 }

    const loginClickHandler = e => {
      this.setState({
         content: <Login />
      })

    };

    return (
      <>
        {/* <!-- Background image --> */}
        <div class="p-5 text-center bg-image" style={{ 'background-image': "url('https://mdbcdn.b-cdn.net/img/new/slides/041.webp')", 'height': 400, 'margin-top': 58 }}>
          <div class="mask" style={{ 'background-color': 'rgba(0, 0, 0, 0.6)' }}>
            <div class="d-flex justify-content-center align-items-center">
              <div class="text-white">
                <h1 class="mb-3">Heading</h1>
                <h4 class="mb-3">Subheading</h4>
                <a class="btn btn-outline-light btn-lg" href="#!" role="button">Call to action</a><br /> <br />

                <Button id={"btLogin"} value={"Sign In"} className={'btn-primary'} clickHandler={loginClickHandler} style={style} /> <br /> <br />
                <div>{this.state.content}</div>
              </div>

            </div>
          </div>
        </div>
        {/* <!-- Background image --> */}

      </>
    )
  }
}

export default Banner