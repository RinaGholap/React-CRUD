import React, { Component } from 'react'
import Button from './Button';

export class Filter extends Component {

  render() {
    const grades = [10, 2, 21, 35, 50, -10, 0, 1];

    // get all grades > 20
    const result = grades.filter(grade => grade > 20); // [21, 35, 50];

    // get all grades > 30
    grades.filter(grade => grade > 30); // [35, 50]


    function getPassingTests(results) {
      return results.filter(result => result.grade >= 10)
    }

    // sample usage (do not modify)
    const data = [{
      'id': 1,
      'grade': 10
    }, {
      'id': 2,
      'grade': 4
    }, {
      'id': 3,
      'grade': 18
    }]

    const insertClickHandler = e => {
      alert("Clicked on insert Button");
    };
  
    const saveClickHandler = e => {
      alert("Clicked on save Button");
    };

  
    var style={'border-radius': 30, 'width': 100, 'margin-right': 20}

    return (
      
      <>
        Filter
        <h6>{result.join(' ')}</h6>
        <p>{JSON.stringify(getPassingTests(data))}</p>
        <h3>Button reusable component example</h3>
        <Button
        id={"btnInsert"}
        type={"Submit"}
        value={"Insert"}
        className={'btn-primary'}
        clickHandler={insertClickHandler}
        style={style}
      />
      <Button
        id={"btnSave"}
        type={"Submit"}
        value={"Save"}
        className={'btn-secondary'}
        clickHandler={saveClickHandler}
        style={style}
      />

      </>
    )
  }
}

export default Filter