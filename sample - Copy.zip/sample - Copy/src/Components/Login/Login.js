import React, { Component } from 'react'

export class Login extends Component {
  render() {
    return (
      <div>Login</div>
    )
  }
}

export default Login