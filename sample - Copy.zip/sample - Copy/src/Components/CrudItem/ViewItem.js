import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Formik, Form, Field } from 'formik';

const ViewItem = () => {
  const { id } = useParams(); // Get the item ID from the URL parameter
  const [item, setItem] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch the item data based on the ID from the URL parameter
    fetch(`http://localhost:3000/items/${id}`)
      .then((response) => response.json())
      .then((data) => {
        setItem(data);
        setLoading(false);
      });
  }, [id]);

  return (
    <div>
      <h1>View Item Details</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <Formik initialValues={item}>
          <Form>
            <div>
              <label htmlFor="name">Name:</label>
              <Field type="text" id="name" name="name" readOnly />
            </div>
            <div>
              <label htmlFor="description">Description:</label>
              <Field as="textarea" id="description" name="description" readOnly />
            </div>
            <div>
              <Link to="/">Back</Link>
            </div>
          </Form>
        </Formik>
      )}
    </div>
  );
};

export default ViewItem;
