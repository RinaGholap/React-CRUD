// EditItem.js
import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object({
  name: Yup.string().required('Name is required'),
});

const EditItem = () => {
  const { id } = useParams();
  const [item, setItem] = useState({});
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`http://localhost:3000/items/${id}`)
      .then((response) => response.json())
      .then((data) => {
        setItem(data);
        setName(data.name);
        setLoading(false);
      });
  }, [id]);

  const handleSubmit = (values) => {
    // Send a PUT request to update the item
    fetch(`http://localhost:3000/items/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(values),
    }).then(() => {
      // Redirect to the item list after updating
      window.location.href = '/';
    })
    .catch((error) => {
      // Handle any errors here
      console.error('Error updating item:', error);
    });
  };

  return (
    <div>
    <h1>Edit Item</h1>
    {loading ? (
      <p>Loading...</p>
    ) : (
      <Formik
        initialValues={{ name: item.name || '' }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <div>
            <label htmlFor="name">Name:</label>
            <Field type="text" id="name" name="name" />
            <ErrorMessage name="name" component="div" className="error" />
          </div>
          <div>
            <button type="submit">Save</button>
            <Link to="/">Back</Link>
          </div>
        </Form>
      </Formik>
    )}
  </div>
  );
};

export default EditItem;
