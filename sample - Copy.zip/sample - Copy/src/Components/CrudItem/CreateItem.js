import React from 'react';
import { Link } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const validationSchema = Yup.object({
  name: Yup.string().required('Name is required'),
});

const CreateItem = () => {
  const initialValues = {
    name: '',
  };

  const handleSubmit = (values) => {
    // Send a POST request to the server to create the new item
    fetch('http://localhost:3000/items', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(values),
    })
      .then(() => {
        // Show a success message using react-toastify
        toast.success('Item created successfully', {
          position: 'top-right',
          autoClose: 3000, // Close the message after 3 seconds
        });
        // Redirect to the home page after creating the item
        window.location.href = '/';
      })
      .catch((error) => {
        // Handle any errors here
        console.error('Error creating item:', error);
      });
  };

  return (
    <div>
      <h1>Create New Item</h1>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <div>
            <label htmlFor="name">Name:</label>
            <Field type="text" id="name" name="name" />
            <ErrorMessage name="name" component="div" className="error" />
          </div>
          <div>
            <button type="submit">Save</button>
            <Link to="/">Back</Link>
          </div>
        </Form>
      </Formik>
      {/* Add ToastContainer to display toast messages */}
      <ToastContainer />
    </div>
  );
};

export default CreateItem;
