import logo from './logo.svg';
import './App.css';
// import Filter from './Components/Filter';
// import Banner from './Components/Banner';
// import Header from './Components/Header';

import { Route, Routes } from 'react-router-dom';
import ItemList from './Components/CrudItem/ItemList';
import CreateItem from './Components/CrudItem/CreateItem';
import EditItem from './Components/CrudItem/EditItem';
import ViewItem from './Components/CrudItem/ViewItem';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      {/* <Header />
      <Banner /> */}
      {/* <Filter /> */}

      <Routes >
         {/* Default route (home page) */}
        <Route path="/" element={<ItemList />} />
        {/* Route for creating a new item */}
        <Route path="/create" element={<CreateItem />} />
         {/* Route for editing an existing item */}
        <Route path="/edit/:id" element={<EditItem />} />
        <Route path="/view/:id" element={<ViewItem />} />
      </Routes>
    </div>
  );
}

export default App;
